function viewmsg(){
    alert("You clicked on image");
}